<?php

require_once ('../../../wp-load.php');
global $wpdb;
$table_name = $wpdb->prefix . 'estimate';
//custom id
//$id = 385;
$id = $_GET['id'];
$your_compnay_name = $_GET['your_compnay_name'];
$results = $wpdb->get_results('SELECT * FROM ' . $table_name . ' WHERE id =' . $id, OBJECT);

$html = '<!doctype html>
<html>
    <head>
        <title>PDF Report</title>
        <link rel="stylesheet" type="text/css" href="style.css" />
    </head>
    <body>
        <div class="custom_container_pdf"> 
                <p class="top-paragraphp font-2rem">Profit Potential for '. $your_compnay_name.' with GoConex:</p>
                <p class="form-paragraph form-paragraph_89rem">Attract customers with features they want. Improve your profit on every home without changing your established systems and capabilities.</p>
                <p class="form-paragraph form-paragraph_89rem">Review your GoConex profit estimates below, then invite your Electrical Trades to do their part in unlocking this profit.</p>
            <hr class="margin-top-40px"/> 
            <table border="0" class="margin-top-80px">
                <tr>
                    <td style="width:500px">
                        <p class="light-red-color-text font-size-1-6rem option-heading-p">MASTER SWITCH</p>
                        <p class="form-paragraph">Turn all the lights on or off with one switch</p>
                    </td>
                    <td rowspan="2" style="margin-top:80px;"> 
                         <img src=' . get_option('content-label-6-2') . ' alt="master sw" style="height:370px; width:250px"/>
                    </td>
                </tr>
                <tr>
                    <td style="width:500px">
                         <img src="http://goconex.com/wp-content/uploads/2015/11/goconex-master-switches-diagram-for-calculator-1.png" alt="master sw"/>
                    </td>
                </tr>
             </table> 
            <table border="0" style="margin-top:40px">
                  <tr>  
                      <td style="width:200px;"> 
                          <p class="form-paragraph_89rem">How many homes you build</p>
                          <p class="form-paragraph_89rem padding-left-20px" style="margin-left:30px;"> $' . $results[0]->option_home_completed . ' </p>
                      </td>
                      <td style="width:50px;text-align:center"> 
                          <p class="form-paragraph_89rem"> X </p>
                      </td>
                     <td style="width:200px; margin-top:50px"> 
                          <p class="form-paragraph_89rem">Buyers who want Master Switch feature</p>
                           <p class="form-paragraph_89rem padding-left-20px" style="margin-left:30px;"> ' . $results[0]->ms_prcnt_home_buyer_cntrctr . '%  </p>
                      </td>
                      <td style="width:50px;text-align:center"> 
                           <p class="form-paragraph_89rem"> = </p>               
                      </td>
                      <td style="width:200px;margin-top:50px"> 
                       <p class="form-paragraph_89rem">Number of buyers for Master Switch </p>
                       <p class="form-paragraph_89rem padding-left-20px" style="margin-left:30px;">  ' . $results[0]->ms_num_buyer_cntrctr . '  </p>
                      </td>
                  </tr>
            </table>
             <table border="0" style="margin-top:40px">
                  <tr>  
                      <td style="width:200px;"> 
                          <p class="form-paragraph_89rem">Number of Master Switches per home</p>
                          <p class="form-paragraph_89rem padding-left-20px" style="margin-left:30px;">  ' . $results[0]->ms_nm_purchased_pr_home_cntrctr . ' </p>
                      </td>
                      <td style="width:50px;text-align:center"> 
                          <p class="form-paragraph_89rem"> X </p>
                      </td>
                     <td style="width:200px; margin-top:50px"> 
                          <p class="form-paragraph_89rem">Number of Master Switch buyers</p>
                           <p class="form-paragraph_89rem padding-left-20px" style="margin-left:30px;"> ' . $results[0]->ms_num_buyer_cntrctr . '  </p>
                      </td>
                      <td style="width:50px;text-align:center"> 
                           <p class="form-paragraph_89rem"> = </p>               
                      </td>
                      <td style="width:200px;margin-top:50px"> 
                       <p class="form-paragraph_89rem">Number of Master Switches sold  </p>
                       <p class="form-paragraph_89rem padding-left-20px" style="margin-left:30px;">  ' . round(number_format((float)($results[0]->ms_nm_purchased_pr_home_cntrctr * $results[0]->ms_num_buyer_cntrctr ), 2, '.', ''), 2). '  </p>
                      </td>
                  </tr>
            </table>
            <table border="0" style="margin-top:40px">
                  <tr>  
                      <td style="width:200px;"> 
                <p class="form-paragraph_89rem">Your Master Switch profit margin</p>
                <p class="form-paragraph_89rem padding-left-20px" style="margin-left:30px;"> $' . $results[0]->ms_feature_sell_price_cntrctr . '  </p>
                      </td>
                      <td style="width:50px;text-align:center"> 
                          <p class="form-paragraph_89rem"> X </p>
                      </td>
                     <td style="width:200px;"> 
                <p class="form-paragraph_89rem">Number of Master Switches sold </p>
                <p class="form-paragraph_89rem padding-left-20px">'.round(number_format((float)($results[0]->ms_nm_purchased_pr_home_cntrctr * $results[0]->ms_num_buyer_cntrctr ), 2, '.', ''), 2).'</p>
                      </td>
                      <td style="width:50px;text-align:center"> 
                           <p class="form-paragraph_89rem"> = </p>               
                      </td>
                      <td style="width:200px;border:1px solid #ccc;border-radius:5px;padding:10px">               
                <p class="form-paragraph_89rem no-right-margin">Total Master Switch profit:</p>
                <p class="padding-left-20px light-red-color-text font-size-1-6rem  display-inline option-heading-p"> $' . $results[0]->ms_gross_proftit_cntrctr . ' </p>
            </td>
            </tr>
            </table>
            <br>
            <hr/>            
            <table border="0" class="margin-top-80px">
                <tr>
                    <td style="width:500px">
                        <p class="light-red-color-text font-size-1-6rem light-red-color-text">ZONE SWITCH</p>
                        <p class="form-paragraph">Turn multiple rooms on or off with one switch</p>
                    </td>
                    <td rowspan="2" style="margin-top:80px;"> 
                         <img src='. get_option('content-label-6-3') .' alt="zone sw" style="height:370px; width:250px"/>
                    </td>
                </tr>
                <tr>
                    <td style="width:500px">
                         <img src="http://goconex.com/wp-content/uploads/2015/11/goconex-zone-switches-diagram-for-calculator-2.png" alt="master sw"/>
                    </td>
                </tr>
             </table> 
            <table border="0" style="margin-top:40px">
                  <tr>  
                      <td style="width:200px;"> 
                          <p class="form-paragraph_89rem">How many homes you build</p>
                          <p class="form-paragraph_89rem padding-left-20px" style="margin-left:30px;"> $' . $results[0]->option_home_completed . ' </p>
                      </td>
                      <td style="width:50px;text-align:center"> 
                          <p class="form-paragraph_89rem"> X </p>
                      </td>
                     <td style="width:200px; margin-top:50px"> 
                          <p class="form-paragraph_89rem">Buyers who want Zone Switch feature </p>
                           <p class="form-paragraph_89rem padding-left-20px" style="margin-left:30px;"> ' . $results[0]->zn_prcnt_home_buyer_cntrctr . '%  </p>
                      </td>
                      <td style="width:50px;text-align:center"> 
                           <p class="form-paragraph_89rem"> = </p>               
                      </td>
                      <td style="width:200px;margin-top:50px"> 
                       <p class="form-paragraph_89rem">Number of buyers for Zone Switch </p>
                       <p class="form-paragraph_89rem padding-left-20px" style="margin-left:30px;">  ' . $results[0]->zn_num_buyer_cntrctr . '  </p>
                      </td>
                  </tr>
            </table>
             <table border="0" style="margin-top:40px">
                  <tr>  
                      <td style="width:200px;"> 
                          <p class="form-paragraph_89rem">Number of Zone Switches per home</p>
                          <p class="form-paragraph_89rem padding-left-20px" style="margin-left:30px;">  ' . $results[0]->zn_nm_purchased_pr_home_cntrctr . ' </p>
                      </td>
                      <td style="width:50px;text-align:center"> 
                          <p class="form-paragraph_89rem"> X </p>
                      </td>
                     <td style="width:200px; margin-top:50px"> 
                          <p class="form-paragraph_89rem">Number of Zone Switch buyers</p>
                           <p class="form-paragraph_89rem padding-left-20px" style="margin-left:30px;"> ' . $results[0]->zn_num_buyer_cntrctr . '  </p>
                      </td>
                      <td style="width:50px;text-align:center"> 
                           <p class="form-paragraph_89rem"> = </p>               
                      </td>
                      <td style="width:200px;margin-top:50px"> 
                       <p class="form-paragraph_89rem">Number of Zone Switches sold  </p>
                       <p class="form-paragraph_89rem padding-left-20px" style="margin-left:30px;">  ' . round(number_format((float)($results[0]->zn_nm_purchased_pr_home_cntrctr * $results[0]->zn_num_buyer_cntrctr ), 2, '.', ''), 2). '  </p>
                      </td>
                  </tr>
            </table>
            <table border="0" style="margin-top:40px">
                  <tr>  
                      <td style="width:200px;"> 
                <p class="form-paragraph_89rem">Your Zone Switch profit margin</p>
                <p class="form-paragraph_89rem padding-left-20px" style="margin-left:30px;"> $' . $results[0]->zn_feature_sell_price_cntrctr . '  </p>
                      </td>
                      <td style="width:50px;text-align:center"> 
                          <p class="form-paragraph_89rem"> X </p>
                      </td>
                     <td style="width:200px;"> 
                <p class="form-paragraph_89rem">Number of Zone Switches sold </p>
                <p class="form-paragraph_89rem padding-left-20px">'.round(number_format((float)($results[0]->zn_nm_purchased_pr_home_cntrctr * $results[0]->zn_num_buyer_cntrctr ), 2, '.', ''), 2).'</p>
                      </td>
                      <td style="width:50px;text-align:center"> 
                           <p class="form-paragraph_89rem"> = </p>               
                      </td>
                      <td style="width:200px;border:1px solid #ccc;border-radius:5px;padding:10px">               
                <p class="form-paragraph_89rem no-right-margin">Total Zone Switch profit:</p>
                <p class="padding-left-20px light-red-color-text font-size-1-6rem  display-inline light-red-color-text"> $' . $results[0]->zn_gross_proftit_cntrctr . ' </p>
            </td>
            </tr>
            </table>
            <hr style="margin-top:11px; margin-bottom:11px; padding:0px;">
            <table border="0">
                <tr>
                    <td style="width:500px">
                        <p class="light-red-color-text font-size-1-6rem yello-grean-color">PORTABLE SWITCH</p>
                        <p class="form-paragraph">Turn multiple rooms on or off with one switch</p>
                    </td>
                    <td rowspan="2" style="margin-top:80px;"> 
                         <img src=' . get_option('content-label-6-4') . ' alt="master sw" style="height:370px; width:250px"/>
                    </td>
                </tr>
                <tr>
                    <td style="width:500px">
                         <img src="http://goconex.com/wp-content/uploads/2015/11/goconex-portable-switches-diagram-for-calculator-3.png" alt="portable sw"/>
                    </td>
                </tr>
             </table> 
            <table border="0" style="margin-top:40px">
                  <tr>  
                      <td style="width:200px;"> 
                          <p class="form-paragraph_89rem">How many homes you build</p>
                          <p class="form-paragraph_89rem padding-left-20px" style="margin-left:30px;"> $' . $results[0]->option_home_completed . ' </p>
                      </td>
                      <td style="width:50px;text-align:center"> 
                          <p class="form-paragraph_89rem"> X </p>
                      </td>
                     <td style="width:200px; margin-top:50px"> 
                          <p class="form-paragraph_89rem">Buyers who want Portable Switch feature</p>
                           <p class="form-paragraph_89rem padding-left-20px" style="margin-left:30px;"> ' . $results[0]->ps_prcnt_home_buyer_cntrctr . '%  </p>
                      </td>
                      <td style="width:50px;text-align:center"> 
                           <p class="form-paragraph_89rem"> = </p>               
                      </td>
                      <td style="width:200px;margin-top:50px"> 
                       <p class="form-paragraph_89rem">Number of buyers for Portable Switch </p>
                       <p class="form-paragraph_89rem padding-left-20px" style="margin-left:30px;">  ' . $results[0]->ps_num_buyer_cntrctr . '  </p>
                      </td>
                  </tr>
            </table>
             <table border="0" style="margin-top:40px">
                  <tr>  
                      <td style="width:200px;"> 
                          <p class="form-paragraph_89rem">Number of Portable Switches per home</p>
                          <p class="form-paragraph_89rem padding-left-20px" style="margin-left:30px;">  ' . $results[0]->ps_nm_purchased_pr_home_cntrctr . ' </p>
                      </td>
                      <td style="width:50px;text-align:center"> 
                          <p class="form-paragraph_89rem"> X </p>
                      </td>
                     <td style="width:200px; margin-top:50px"> 
                          <p class="form-paragraph_89rem">Number of Portable Switch buyers</p>
                           <p class="form-paragraph_89rem padding-left-20px" style="margin-left:30px;"> ' . $results[0]->ps_num_buyer_cntrctr . '  </p>
                      </td>
                      <td style="width:50px;text-align:center"> 
                           <p class="form-paragraph_89rem"> = </p>               
                      </td>
                      <td style="width:200px;margin-top:50px"> 
                       <p class="form-paragraph_89rem">Number of Portable Switches sold  </p>
                       <p class="form-paragraph_89rem padding-left-20px" style="margin-left:30px;">  ' . round(number_format((float)($results[0]->ps_nm_purchased_pr_home_cntrctr * $results[0]->ps_num_buyer_cntrctr ), 2, '.', ''), 2). '  </p>
                      </td>
                  </tr>
            </table>
            <table border="0" style="margin-top:40px">
                  <tr>  
                      <td style="width:200px;"> 
                <p class="form-paragraph_89rem">Your Portable Switch profit margin</p>
                <p class="form-paragraph_89rem padding-left-20px" style="margin-left:30px;"> $' . $results[0]->ps_feature_sell_price_cntrctr . '  </p>
                      </td>
                      <td style="width:50px;text-align:center"> 
                          <p class="form-paragraph_89rem"> X </p>
                      </td>
                     <td style="width:200px;"> 
                <p class="form-paragraph_89rem">Number of Portable Switches sold </p>
                <p class="form-paragraph_89rem padding-left-20px">'.round(number_format((float)($results[0]->ps_nm_purchased_pr_home_cntrctr * $results[0]->ps_num_buyer_cntrctr ), 2, '.', ''), 2).'</p>
                      </td>
                      <td style="width:50px;text-align:center"> 
                           <p class="form-paragraph_89rem"> = </p>               
                      </td>
                      <td style="width:200px;border:1px solid #ccc;border-radius:5px;padding:10px">               
                <p class="form-paragraph_89rem no-right-margin">Total Portable Switch profit:</p>
                <p class="padding-left-20px light-red-color-text font-size-1-6rem  display-inline yello-grean-color"> $' . $results[0]->ps_gross_proftit_cntrctr . ' </p>
            </td>
            </tr>
            </table>
            <br>
            <hr/>


<table border="0" style="margin-top:80px;">
                <tr>
                    <td style="width:700px">
                        <p class="light-red-color-text font-size-1-6rem green-color-text">PROFIT ESTIMATE</p>
                        <p class="form-paragraph">Potential profit from new value options for Home Buyers</p>
                    </td>
                </tr>
             </table> 
            <table border="0" style="margin-top:40px">
                  <tr>  
                      <td style="width:120px;"> 
                <p class="form-paragraph_89rem">Master Switch</p>
                <p class="form-paragraph_89rem padding-left-20px" style="margin-left:30px;"> $' . $results[0]->ms_gross_proftit_cntrctr . '  </p>
                      </td>
                      <td style="width:50px;text-align:center"> 
                          <p class="form-paragraph_89rem"> + </p>
                      </td>
                     <td style="width:120px;"> 
                <p class="form-paragraph_89rem">Zone Switch </p>
                <p class="form-paragraph_89rem padding-left-20px">$' . $results[0]->zn_gross_proftit_cntrctr .'</p>
                      </td>
                      <td style="width:50px;text-align:center"> 
                          <p class="form-paragraph_89rem"> + </p>
                      </td>
                     <td style="width:120px;"> 
                <p class="form-paragraph_89rem">Portable Switch </p>
                <p class="form-paragraph_89rem padding-left-20px">$' . $results[0]->ps_gross_proftit_cntrctr .'</p>
                      </td>
                      <td style="width:50px;text-align:center"> 
                           <p class="form-paragraph_89rem"> = </p>               
                      </td>
                      <td style="width:200px;border:1px solid #ccc;border-radius:5px;padding:10px">               
                <p class="form-paragraph_89rem no-right-margin">Total annual increase in gross profit </p>
                <p class="padding-left-20px light-red-color-text font-size-1-6rem  display-inline green-color-text"> $' . $results[0]->sum_ms_zn_ps_cntrctr . ' </p>
            </td>
            </tr>
            </table>
            <hr class="margin-top-40px"/>
            <div class=" border-solid-1px top_header margin-top-40px">
                <p class="top-paragraphp"> Your Electrical Trades will help you get this money. </p>
            </div>
            <div class="margin-top-40px">
                <p class="form-paragraph_89rem no-right-margin">Invite your contractors to tell you why traditional wiring is expensive and explain the negative impact on your bottom line.</p>
                <p class="form-paragraph_89rem no-right-margin">They will share your excitement about GoConex profit potential.</p>
            </div>
            <div class="margin-top-40px pdf_button">
                              <img src="' . get_bloginfo('url') . '/wp-content/plugins/goconex-calculator-pdf-vendor/invite-electrical-contractor.jpg" alt="company_icon" /> 
            </div>            
            <div class="clear_both"></div>
            <hr class="margin-top-40px"/>
            <div class=" border-solid-1px top_header margin-top-40px">
                <p class="top-paragraphp">Explore GoConex for your business</p>
            </div>
            <div class="margin-top-40px">
                <p class="form-paragraph_89rem no-right-margin">Contact GoConex directly. We can confirm your profit estimates and help onboard your electrical trades.</p>
            </div>
            <div class="margin-top-40px pdf_button">
                <img src="' . get_bloginfo('url') . '/wp-content/plugins/goconex-calculator-pdf-vendor/contact-goconex.jpg" alt="company_icon" /> 
            </div>
            <div class="clear_both"></div>
            <hr class="margin-top-40px"/>
            <div class="margin-top-40px pdf_button">
                <img src="' . get_bloginfo('url') . '/wp-content/plugins/goconex-calculator-pdf-vendor/goconex-logo.jpg" alt="company_logo" /> 
            </div>
            <div class="margin-top-40px">
                <p class="form-paragraph_89rem no-right-margin">GoConex is proudly manufacturered by Levven Electronics in Alberta, Canada. </p>
            </div>
            <div class="pdf_column left_float">
                <p class="form-paragraph_89rem">Levven Electronics Ltd <br/> 9741 54 Ave  <br/>  Edmonton, Alberta, Canada <br/>  T6E 5J4</p>
                <p class="form-paragraph_89rem">Email:<a href="mailto:sales@levven.com ">sales@levven.com </a> <br/> Phone: 780-391-3000 <br/> Web: <a href="http://levven.com">http://levven.com</a></p>
            </div>
            <div class="pdf_column left_float padding-top-20">
                <img src="' . get_bloginfo('url') . '/wp-content/plugins/goconex-calculator-pdf-vendor/company_icon_03.jpg" alt="company_icon" />                
            </div>
            <div class="clear_both"></div>
        </div>
    </body>
</html>';

//echo $html;
include("mpdf60/mpdf.php");
$mpdf = new mPDF('c');

$mpdf->mirrorMargins = false;
$stylesheet = file_get_contents('style.css');
$mpdf->WriteHTML($stylesheet, 1); // The parameter 1 tells that this is css/style only and no body/html/text

$mpdf->WriteHTML($html);

$mpdf->Output();
exit;
