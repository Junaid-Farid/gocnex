<?php

/*
  Plugin Name: Goconex Calculator PDF vendor
  Plugin URI: http://optimageeks.com
  Description: Plugin for Goconex calculator to genrate pdf
  Version: 0.01
  Author: OptimaGeeks
  Author URI: http://optimageeks.com
 */
