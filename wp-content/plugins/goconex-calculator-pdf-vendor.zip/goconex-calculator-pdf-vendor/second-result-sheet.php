<?php

require_once ('../../../wp-load.php');
global $wpdb;
$table_name = $wpdb->prefix . 'estimate';
$results = $wpdb->get_results('SELECT * FROM ' . $table_name . ' WHERE id =' . $_GET['id'], OBJECT);
$html = '<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Second Result Sheet</title>
</head>

<body>
<p><h1>Second Result Sheet</h1></p>
 <h2>Second Result Sheet Profit Results:</h2> 
<table width="100%" border="1">
  <tbody>
    <tr>
      <td colspan="5"><h2 style="color:#BB171A">GOOD:</h2></td>
    </tr>
    <tr>
      <td colspan="4"><h3>Use GoConex for all your power control needs</h3></td>
      <td>&nbsp;</td>
    </tr>
    <tr>
      <td>Total GoConex value foryour existing business</td>
      <td rowspan="2"> / </td>
      <td>Homes/Units per year</td>
      <td rowspan="2">= </td>
      <td>GoConex value per home to your business</td>
    </tr>
    <tr>
      <td>$ ' . $results[0]->gc_pwr_cntrl_total . '</td>
      <td>$ ' . $results[0]->nm_home_cmpltd_pr_yr . '</td>
      <td> $ ' . $results[0]->gc_pwr_cntrl_adjust_staff_vlue_pr_hme . '</td>
    </tr>
    <tr>
      <td>Total GoConex option profit for Builder</td> 
      <td rowspan="2"> / </td>
      <td>Homes/Units per year</td>
      <td rowspan="2">= </td>
      <td>Builder profit from Options per home</td>
    </tr>
    <tr>
      <td> $ ' . $results[0]->gc_pwr_cntrl_bldr_option_prce_pr_hme . '</td>
      <td> $ ' . $results[0]->nm_home_cmpltd_pr_yr . '</td>
      <td>$ ' . $results[0]->builder_price_price_per_home . '</td>
    </tr>
    <tr>
      <td colspan="5">Of this $$ ' . $results[0]->builder_price_price_per_home . ' per home, how much would the Builder be willing to share with you?</td>
    </tr>
    <tr>
      <td colspan="3">Slider Input here</td>
      <td>&nbsp;</td>
      <td>&nbsp;</td>
    </tr>
    <tr>
      <td>GoConex value per home to your business</td>
      <td rowspan="2">+</td>
      <td>Builder willing to share 50% of their per home profit</td>
      <td rowspan="2">=</td>
      <td>Total GoConex value per home:</td>
    </tr>
    <tr>
      <td>$ ' . $results[0]->gc_pwr_cntrl_adjust_staff_vlue_pr_hme . '</td>
      <td>$ ' . $results[0]->builder_price_price_per_home . '</td>
      <td style="color:#BB171A">$ ' . $results[0]->gc_pwr_cntrl_total_vlu_dlr_pr_hme . '</td>
    </tr>
    <tr>
      <td colspan="5"><h2 style="color:#F15A24">BETTER:</h2></td>
    </tr>
    <tr>
      <td colspan="5"><h3>Use GoConex for all your power control needs PLUS right-size your staff for efficiency</h3></td>
    </tr>
    <tr>
      <td>Total GoConex value foryour existing business</td>
      <td rowspan="2">/</td>
      <td>Homes/Units per year</td>
      <td rowspan="2">=</td>
      <td>GoConex value per home to your business</td>
    </tr>
    <tr>
      <td>$ ' . $results[0]->gc_pwr_cntrl_total_adjust_staff . '</td>
      <td>$ ' . $results[0]->nm_home_cmpltd_pr_yr . '</td>
      <td>$ ' . $results[0]->gc_pwr_cntrl_adjust_staff_vlue_pr_hme . '</td>
    </tr>
    <tr>
      <td>GoConex value per home to your business</td>
      <td rowspan="2"> + </td>
      <td>Builder willing to share 50% of their per home profit</td>
      <td rowspan="2">= </td>
      <td>Total GoConex value per home:</td>
    </tr>
    <tr>
      <td> $ ' . $results[0]->gc_pwr_cntrl_adjust_staff_vlue_pr_hme . '</td>
      <td>$' . $results[0]->builder_price_price_per_home . '</td>
      <td style="color:#F15A24">$ ' . $results[0]->gc_pwr_cntrl_adjust_staff_dlr_vlue_pr_hme . '</td>
    </tr>
    <tr>
      <td colspan="5"><h2 style="color:#6D9900">BSET:</h2></td>
    </tr>
    <tr>
      <td colspan="5"><h3>BEST:Use GoConex for all your power control needs PLUS grow your business with <span style="color:#6D9900">106 additional homes/installations </span>this year</h3></td>
    </tr>
    <tr>
      <td>Total GoConex value foryour existing business</td>
      <td rowspan="2"> = </td>
      <td>Homes/Units per year</td>
      <td rowspan="2"> = </td>
      <td>GoConex value per home to your business</td> 
    </tr>
    <tr>
      <td>$ ' . $results[0]->gc_pwr_cntrl_do_more_exstng_rsrces_total . '</td>
      <td>$ ' . $results[0]->nm_home_cmpltd_pr_yr . '</td>
      <td>$ ' . $results[0]->gc_pwr_cntrl_do_more_exstng_rsrces_vlue_pr_hme . '</td>
    </tr>
    <tr>
      <td>GoConex value per home to your business</td>
      <td rowspan="2"> + </td>
      <td>Builder willing to share 50% of their per home profit</td>
      <td rowspan="2"> = </td>
      <td>Total GoConex value per home:</td>
    </tr>
    <tr>
      <td>$ ' . $results[0]->gc_pwr_cntrl_do_more_exstng_rsrces_vlue_pr_hme . '</td>
      <td>$ ' . $results[0]->builder_price_price_per_home . '</td>
      <td style="color:#6D9900">$ ' . $results[0]->gc_pwr_cntrl_do_more_exstng_rsrces_dlr_vlue_pr_hme . '</td>
    </tr>
  </tbody>
</table>

</body>
</html> ';

include("mpdf60/mpdf.php");
$mpdf = new mPDF('c');

$mpdf->mirrorMargins = true;

$mpdf->WriteHTML($html);

$mpdf->Output();
exit;

