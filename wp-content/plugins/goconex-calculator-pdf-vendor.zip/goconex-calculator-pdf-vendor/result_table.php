<?php

require_once ('../../../wp-load.php');
global $wpdb;
$table_name = $wpdb->prefix . 'estimate';
//custom id
//$id = 385;
$id = $_GET['id'];
$results = $wpdb->get_results('SELECT * FROM ' . $table_name . ' WHERE id =' . $id, OBJECT);

$final_question = $_GET['profit_you_need'];
$your_compnay_name = $_GET['your_compnay_name'];
$num_completed_pr_year = $results[0]->nm_home_cmpltd_pr_yr;
$total_switch_per_home = $results[0]->total_nm_sw_in_home;

$max_pay_on_needed_profit = round(number_format((float) ($final_question / ($total_switch_per_home * $num_completed_pr_year)), 2, '.', ''), 2);

$optimize_strategy_total = $results[0]->gc_pwr_cntrl_adjust_staff_dlr_vlue_pr_hme;
$grow_strategy_total =   $results[0]->gc_pwr_cntrl_do_more_exstng_rsrces_dlr_vlue_pr_hme;
$mtrial_and_labour_cost = $results[0]->tr_matrial_and_lbr_cst;



$available_value_dollar_resour_efficieny = round(number_format((float) ($optimize_strategy_total + $mtrial_and_labour_cost), 2, '.', ''), 2);
$available_value_dollar_exstng_rs_people = round(number_format((float) ($grow_strategy_total + $mtrial_and_labour_cost), 2, '.', ''), 2);

$max_pay_still_prift_efficiency = round(number_format((float) ($available_value_dollar_resour_efficieny / $total_switch_per_home), 2, '.', ''), 2);
$max_pay_still_prift_rs_people = round(number_format((float) ($available_value_dollar_exstng_rs_people / $total_switch_per_home), 2, '.', ''), 2);

$adjust_resource = $max_pay_still_prift_efficiency - $max_pay_on_needed_profit;
$grow_business = $max_pay_still_prift_rs_people - $max_pay_on_needed_profit;
$html = '<!doctype html>
<html>
    <head>
        <title>PDF Report</title>
        <link rel="stylesheet" type="text/css" href="style.css" />
    </head>
    <body>
        <div class="custom_container_pdf">
            <div class=" border-solid-1px top_header">
                <p class="top-paragraphp">Results for '.$your_compnay_name.' with GoConex:</p>
            </div>
            <div class="margin-top-80px">
            <p>'.$mtrial_and_labour_cost.'</p>
            <p>'.$num_completed_pr_year.'</p>
                <p class="light-red-color-text font-size-1-3em">"OPTIMIZE" STRATEGY:</p>
                <p class="form-paragraph">Use GoConex for power control PLUS optimize staff with ' . $results[0]->efficiency_gain . '% efficiency</p>
            </div>
            <table border="0" style="margin-top:40px">
                  <tr>  
                      <td style="width:200px;"> 
                          <p class="form-paragraph_89rem">Potential GoConex value for your existing business</p>
                          <p class="form-paragraph_89rem padding-left-20px"> $' . $results[0]->gc_pwr_cntrl_total_adjust_staff . ' </p>
                      </td>
                      <td style="width:50px;text-align:center"> 
                          <p class="form-paragraph_89rem"> / </p>
                      </td>
                     <td style="width:200px;"> 
                          <p class="form-paragraph_89rem">Homes/Units per year</p>
                           <p class="form-paragraph_89rem padding-left-20px"> ' . $num_completed_pr_year . '  </p>
                      </td>
                      <td style="width:50px;text-align:center"> 
                           <p class="form-paragraph_89rem"> = </p>               
                      </td>
                      <td style="width:200px;"> 
                       <p class="form-paragraph_89rem">GoConex value per home</p>
                       <p class="form-paragraph_89rem padding-left-20px"> $' . $results[0]->gc_pwr_cntrl_adjust_staff_vlue_pr_hme . '  </p>
                      </td>
                  </tr>
            </table>
            <div class="clear_both"></div>
            <table border="0" style="margin-top:40px">
                  <tr>  
                      <td style="width:200px;"> 
                <p class="form-paragraph_89rem">GoConex value per home</p>
                <p class="form-paragraph_89rem padding-left-20px"> $' . $results[0]->gc_pwr_cntrl_adjust_staff_vlue_pr_hme . '  </p>
                      </td>
                      <td style="width:50px;text-align:center"> 
                          <p class="form-paragraph_89rem"> + </p>
                      </td>
                     <td style="width:200px;"> 
                <p class="form-paragraph_89rem">Builder sharing ' . $results[0]->builder_share . '% of their per home profit</p>
                <p class="form-paragraph_89rem padding-left-20px"> $' . $results[0]->builder_willing_share . ' </p>
                      </td>
                      <td style="width:50px;text-align:center"> 
                           <p class="form-paragraph_89rem"> = </p>               
                      </td>
                      <td style="width:200px;border:1px solid #ccc;border-radius:5px;padding:10px">               
                <p class="form-paragraph_89rem no-right-margin">Total GoConex value per home:</p>
                <p class="padding-left-20px light-red-color-text font-size-1-3em  display-inline"> $' . $results[0]->gc_pwr_cntrl_adjust_staff_dlr_vlue_pr_hme . ' </p>
            </td>
            </tr>
            </table>
            <br>
            <div class="clear_both"></div>
            <hr/>
                <p class="light-green-color-text font-size-1-3em">"GROW" STRATEGY:</p>
                <p class="form-paragraph" style="text-align:left">Use GoConex for power control PLUS grow with ' . $results[0]->total_pssble_added_roughin_pr_anm . ' additional installations this year</p>
                <table border="0" style="margin-top:40px">
                  <tr>  
                      <td style="width:200px;"> 
                <p class="form-paragraph_89rem">Potential GoConex value  for your business</p>
                <p class="form-paragraph_89rem padding-left-20px"> $' . $results[0]->gc_pwr_cntrl_do_more_exstng_rsrces_total . ' </p>                      </td>
                      <td style="width:50px;text-align:center"> 
                          <p class="form-paragraph_89rem"> / </p>
                      </td>
                     <td style="width:200px;"> 
                <p class="form-paragraph_89rem">Homes/Units per year</p>
                <p class="form-paragraph_89rem padding-left-20px"> ' . $results[0]->best_nm_hme_cmpltd_total_possible . ' </p>
                      </td>
                      <td style="width:50px;text-align:center"> 
                           <p class="form-paragraph_89rem"> = </p>               
                      </td>
                      <td style="width:200px;"> 
                 <p class="form-paragraph_89rem">GoConex value  per home</p>
                <p class="form-paragraph_89rem padding-left-20px"> $' . $results[0]->gc_pwr_cntrl_do_more_exstng_rsrces_vlue_pr_hme . ' </p>
                     </td>
                  </tr>
            </table>
            <div class="clear_both"></div>
                <table border="0" style="margin-top:40px">
                  <tr>  
                      <td style="width:200px;"> 
                        <p class="form-paragraph_89rem">GoConex value per home</p>
                <p class="form-paragraph_89rem padding-left-20px"> $' . $results[0]->gc_pwr_cntrl_do_more_exstng_rsrces_vlue_pr_hme . ' </p>
            </td>
                      <td style="width:50px;text-align:center"> 
                          <p class="form-paragraph_89rem"> + </p>
                      </td>
                     <td style="width:200px;"> 
                <p class="form-paragraph_89rem">Builder sharing ' . $results[0]->builder_share . '% of  their per home profit</p>
                <p class="form-paragraph_89rem padding-left-20px"> $' . $results[0]->builder_willing_share . ' </p>
                      </td>
                      <td style="width:50px;text-align:center"> 
                           <p class="form-paragraph_89rem"> = </p>               
                      </td>
                    <td style="width:200px;border:1px solid #ccc;border-radius:5px;padding:10px"> 
                <p class="form-paragraph_89rem no-right-margin">Total GoConex value per home:</p>
                <p class="padding-left-20px light-green-color-text font-size-1-3em  display-inline"> $' . $results[0]->gc_pwr_cntrl_do_more_exstng_rsrces_dlr_vlue_pr_hme . ' </p>
                     </td>
                  </tr>
            </table>
            <hr style="margin-top:20px"/>


            <div class="margin-top-40px">
                <p class="light-purple-color-text font-size-1-3em">TARGET PROFIT:</p>
                <p class="form-paragraph">You said your company could change to GoConex if you earned $' . $final_question . ' in new profit.  At what price do we meet that goal?</p>
            </div>
                        <table border="0" style="margin-top:40px">
                  <tr>  
                      <td style="width:200px;"> 
                <p class="form-paragraph_89rem">"Optimize" Strategy  value per home</p>
                <p class="form-paragraph_89rem padding-left-20px"> $' . $optimize_strategy_total . ' </p>
                      </td>
                      <td style="width:50px;text-align:center"> 
                          <p class="form-paragraph_89rem"> + </p>
                      </td>
                     <td style="width:200px;"> 
                <p class="form-paragraph_89rem">Current Material & Labor  cost for wired switching</p>
                <p class="form-paragraph_89rem padding-left-20px"> $' . $mtrial_and_labour_cost . ' </p>
                      </td>
                      <td style="width:50px;text-align:center"> 
                           <p class="form-paragraph_89rem"> = </p>               
                      </td>
                      <td style="width:200px;"> 
                <p class="form-paragraph_89rem">Available value dollars per home  (without changing your pricing)</p>
                <p class="form-paragraph_89rem padding-left-20px"> $' . $available_value_dollar_resour_efficieny . ' </p>
                      </td>
                  </tr>
            </table>

                        <table border="0" style="margin-top:40px">
                  <tr>  
                      <td style="width:200px;"> 
            <p class="form-paragraph_89rem">"Grow" Strategy  value per home</p>
                <p class="form-paragraph_89rem padding-left-20px">  $'.$grow_strategy_total.' </p>  
                         </td>
                      <td style="width:50px;text-align:center"> 
                          <p class="form-paragraph_89rem"> + </p>
                      </td>
                     <td style="width:200px;"> 
                <p class="form-paragraph_89rem">Current Material & Labor  cost for wired switching</p>
                <p class="form-paragraph_89rem padding-left-20px">  $'.$mtrial_and_labour_cost.' </p>
                      </td>
                      <td style="width:50px;text-align:center"> 
                           <p class="form-paragraph_89rem"> = </p>               
                      </td>
                      <td style="width:200px;"> 
                <p class="form-paragraph_89rem no-right-margin">Available value dollars per home  (without changing your pricing)</p>
                <p class="padding-left-20px form-paragraph_89rem display-inline"> $'.$available_value_dollar_exstng_rs_people.'  </p>
                      </td>
                  </tr>
            </table>


            <div class="clear_both"></div>
                        <table border="0" style="margin-top:40px">
                  <tr>  
                      <td style="width:220px;"> 
                <p class="form-paragraph_89rem">Profit goal needed to  start using GoConex</p>
                <p class="form-paragraph_89rem padding-left-20px"> $' . $final_question . ' </p>
                      </td>
                    
</tr>
<tr>
<td><br></td>
</tr>
<tr>
                     <td style="width:250px;border:1px solid #ccc;border-radius:5px;padding:10px"> 
                <p class="form-paragraph_89rem">Price you can pay and achieve target  profit with "Optimize" Strategy</p>
                <p class="font-size-1-3em light-red-color-text padding-left-20px display-inline ">  $' . $adjust_resource . ' per switch</p> 
                      </td>
                      <td style="width:20px"></td>
                      <td style="width:250px;border:1px solid #ccc;border-radius:5px;padding:10px"> 
                <p class="form-paragraph_89rem">Price you can pay and achieve target  profit with "Grow" Strategy</p>
                <p class="font-size-1-3em light-green-color-text padding-left-20px display-inline "> $' . $grow_business . ' per switch</p> 
                      </td>
                  </tr>
            </table>
 

            <div class="clear_both"></div>
            <hr class="margin-top-40px"/>
            <div class=" border-solid-1px top_header margin-top-40px">
                <p class="top-paragraphp">Will you change to GoConex if we can accommodate the pricing above?</p>
            </div>
            <div class="margin-top-40px">
                <p class="form-paragraph_89rem no-right-margin">Send an email to businessvalue@goconex.com. We will call you to answer any questions you have about the above estimates.</p>
            </div>
            <div class="margin-top-40px pdf_button">
                              <img src="'.get_bloginfo('url').'/wp-content/plugins/goconex-calculator-pdf-vendor/email-goconex_03.jpg" alt="company_icon" /> 
            </div>            
            <div class="clear_both"></div>
            <hr class="margin-top-40px"/>
            <div class=" border-solid-1px top_header margin-top-40px">
                <p class="top-paragraphp">Discuss GoConex with your Home Builder clients</p>
            </div>
            <div class="margin-top-40px">
                <p class="form-paragraph_89rem no-right-margin">Excite your builders with new features and new profit without increasing their cost.</p>
            </div>
            <div class="margin-top-40px pdf_button">
                <img src="'.get_bloginfo('url').'/wp-content/plugins/goconex-calculator-pdf-vendor/email-view-builder_03.jpg" alt="company_icon" /> 
            </div>
            <div class="clear_both"></div>
            <hr class="margin-top-40px"/>
            <div class="margin-top-40px">
                <p class="form-paragraph_89rem no-right-margin">GoConex is proudly manufacturered by Levven Electronics in Alberta, Canada. </p>
            </div>
            <div class="pdf_column left_float">
                <p class="form-paragraph_89rem">Levven Electronics Ltd <br/> 9741 54 Ave  <br/>  Edmonton, Alberta, Canada <br/>  T6E 5J4</p>
                <p class="form-paragraph_89rem">Email:<a href="mailto:sales@levven.com ">sales@levven.com </a> <br/> Phone: 780-391-3000 <br/> Web: <a href="http://levven.com">http://levven.com</a></p>
            </div>
            <div class="pdf_column left_float padding-top-20">
                <img src="'.get_bloginfo('url').'/wp-content/plugins/goconex-calculator-pdf-vendor/company_icon_03.jpg" alt="company_icon" />                
            </div>
            <div class="clear_both"></div>
        </div>
    </body>
</html>';

include("mpdf60/mpdf.php");
$mpdf = new mPDF('c');

$mpdf->mirrorMargins = false;
$stylesheet = file_get_contents('style.css');
$mpdf->WriteHTML($stylesheet, 1); // The parameter 1 tells that this is css/style only and no body/html/text

$mpdf->WriteHTML($html);

$mpdf->Output();
exit;
