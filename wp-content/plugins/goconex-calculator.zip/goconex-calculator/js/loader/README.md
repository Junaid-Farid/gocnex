Jquery Loader Plugin
====================

 Just visit : http://www.mimiz.fr/javascript/jquery-loader-plugin/ for usage and http://demos.mimiz.fr/jquery/loader for demo ...



### Development :

 Need Node :

   npm install
   bower install
   grunt test
   grunt