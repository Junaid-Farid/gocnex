<?php
function result_report_process() {
     ///
}